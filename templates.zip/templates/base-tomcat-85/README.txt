Version: 3.2.8.RELEASE
Build Date: 20171009201301

* Add Tomcat 8-specific Servlet 3.1 Specification
* Add Tomcat 8-specific web.xml as a watched resource
