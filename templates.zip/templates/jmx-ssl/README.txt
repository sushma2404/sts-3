Version: 3.2.8.RELEASE
Build Date: 20171009201301

* Updates the JmxSocketListener to use SSL for all JMX communication
* Adds sample certificate and key files that can be used to test the SSL 
configuration
