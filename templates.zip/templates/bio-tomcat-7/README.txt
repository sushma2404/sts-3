Version: 3.2.8.RELEASE
Build Date: 20171009201301

* Adds a Blocking IO (BIO) connector for HTTP
